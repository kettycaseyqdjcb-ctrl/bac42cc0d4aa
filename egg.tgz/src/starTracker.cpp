// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Lost-in-space attitude solve"); }
int main(){
  announce();
  return lionss_run_workload("starTracker");
}
