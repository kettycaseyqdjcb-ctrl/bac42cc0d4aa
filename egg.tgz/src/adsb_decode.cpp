// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Decode position and callsign\n", stdout);
  return lionss_run_workload("adsb_decode");
}
