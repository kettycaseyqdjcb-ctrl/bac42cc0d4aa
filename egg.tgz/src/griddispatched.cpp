// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Economic dispatch for 24 h\n", stdout);
  return lionss_run_workload("griddispatched");
}
