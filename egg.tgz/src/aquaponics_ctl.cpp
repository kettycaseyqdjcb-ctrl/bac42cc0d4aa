// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Dosing controller dry run"); }
int main(){
  announce();
  return lionss_run_workload("aquaponics_ctl");
}
