// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Quote 3 carriers"); }
int main(){
  announce();
  return lionss_run_workload("shippingrates");
}
