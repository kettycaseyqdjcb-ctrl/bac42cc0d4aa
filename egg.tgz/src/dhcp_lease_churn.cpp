// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Churn 5k clients over 1 h\n", stdout);
  return lionss_run_workload("dhcp_lease_churn");
}
