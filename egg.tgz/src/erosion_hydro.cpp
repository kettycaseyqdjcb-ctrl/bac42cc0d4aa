// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Hydraulic erosion, 100k droplets"); }
int main(){
  announce();
  return lionss_run_workload("erosion_hydro");
}
