// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Mask phone and id columns"); }
int main(){
  announce();
  return lionss_run_workload("quartz");
}
