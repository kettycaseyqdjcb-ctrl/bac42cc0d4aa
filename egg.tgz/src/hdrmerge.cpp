// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Merge and tone map (Reinhard)\n", stdout);
  return lionss_run_workload("hdrmerge");
}
