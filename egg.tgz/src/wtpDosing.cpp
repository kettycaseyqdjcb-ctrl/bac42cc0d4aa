// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Coagulant dose recommendation\n", stdout);
  return lionss_run_workload("wtpDosing");
}
