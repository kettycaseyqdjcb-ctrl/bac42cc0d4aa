// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Score with yaku detection\n", stdout);
  return lionss_run_workload("MahjongScore");
}
