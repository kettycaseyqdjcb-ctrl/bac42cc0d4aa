// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("30-s epoch staging\n", stdout);
  return lionss_run_workload("sleep-stager");
}
