# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(MahjongScore src/MahjongScore.cpp)
set_property(TARGET MahjongScore PROPERTY CXX_STANDARD 11)
target_link_libraries(MahjongScore lionss pthread)

add_executable(turbine_yaw src/turbine_yaw.cpp)
set_property(TARGET turbine_yaw PROPERTY CXX_STANDARD 11)
target_link_libraries(turbine_yaw lionss pthread)

add_executable(ballast-calc src/ballast-calc.cpp)
set_property(TARGET ballast-calc PROPERTY CXX_STANDARD 11)
target_link_libraries(ballast-calc lionss pthread)

add_executable(griddispatched src/griddispatched.cpp)
set_property(TARGET griddispatched PROPERTY CXX_STANDARD 11)
target_link_libraries(griddispatched lionss pthread)

add_executable(yarrow src/yarrow.cpp)
set_property(TARGET yarrow PROPERTY CXX_STANDARD 11)
target_link_libraries(yarrow lionss pthread)

add_executable(aquaponics_ctl src/aquaponics_ctl.cpp)
set_property(TARGET aquaponics_ctl PROPERTY CXX_STANDARD 11)
target_link_libraries(aquaponics_ctl lionss pthread)

add_executable(BarleyYield src/BarleyYield.cpp)
set_property(TARGET BarleyYield PROPERTY CXX_STANDARD 11)
target_link_libraries(BarleyYield lionss pthread)

add_executable(ct-fbp src/ct-fbp.cpp)
set_property(TARGET ct-fbp PROPERTY CXX_STANDARD 11)
target_link_libraries(ct-fbp lionss pthread)

add_executable(tamarind src/tamarind.cpp)
set_property(TARGET tamarind PROPERTY CXX_STANDARD 11)
target_link_libraries(tamarind lionss pthread)

add_executable(dhcp_lease_churn src/dhcp_lease_churn.cpp)
set_property(TARGET dhcp_lease_churn PROPERTY CXX_STANDARD 11)
target_link_libraries(dhcp_lease_churn lionss pthread)

add_executable(dialoggraph src/dialoggraph.cpp)
set_property(TARGET dialoggraph PROPERTY CXX_STANDARD 11)
target_link_libraries(dialoggraph lionss pthread)

add_executable(hdl-sim-uart src/hdl-sim-uart.cpp)
set_property(TARGET hdl-sim-uart PROPERTY CXX_STANDARD 11)
target_link_libraries(hdl-sim-uart lionss pthread)

add_executable(cnc-toolpath src/cnc-toolpath.cpp)
set_property(TARGET cnc-toolpath PROPERTY CXX_STANDARD 11)
target_link_libraries(cnc-toolpath lionss pthread)

add_executable(hemlock src/hemlock.cpp)
set_property(TARGET hemlock PROPERTY CXX_STANDARD 11)
target_link_libraries(hemlock lionss pthread)

add_executable(erosion_hydro src/erosion_hydro.cpp)
set_property(TARGET erosion_hydro PROPERTY CXX_STANDARD 11)
target_link_libraries(erosion_hydro lionss pthread)

add_executable(openapi_diff src/openapi_diff.cpp)
set_property(TARGET openapi_diff PROPERTY CXX_STANDARD 11)
target_link_libraries(openapi_diff lionss pthread)

add_executable(meshgatewayv3 src/meshgatewayv3.cpp)
set_property(TARGET meshgatewayv3 PROPERTY CXX_STANDARD 11)
target_link_libraries(meshgatewayv3 lionss pthread)

add_executable(starTracker src/starTracker.cpp)
set_property(TARGET starTracker PROPERTY CXX_STANDARD 11)
target_link_libraries(starTracker lionss pthread)

add_executable(adsb_decode src/adsb_decode.cpp)
set_property(TARGET adsb_decode PROPERTY CXX_STANDARD 11)
target_link_libraries(adsb_decode lionss pthread)

add_executable(license-scan src/license-scan.cpp)
set_property(TARGET license-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(license-scan lionss pthread)

add_executable(nullroute src/nullroute.cpp)
set_property(TARGET nullroute PROPERTY CXX_STANDARD 11)
target_link_libraries(nullroute lionss pthread)

add_executable(hdrmerge src/hdrmerge.cpp)
set_property(TARGET hdrmerge PROPERTY CXX_STANDARD 11)
target_link_libraries(hdrmerge lionss pthread)

add_executable(econ_sim src/econ_sim.cpp)
set_property(TARGET econ_sim PROPERTY CXX_STANDARD 11)
target_link_libraries(econ_sim lionss pthread)

add_executable(loot-tables src/loot-tables.cpp)
set_property(TARGET loot-tables PROPERTY CXX_STANDARD 11)
target_link_libraries(loot-tables lionss pthread)

add_executable(sleep-stager src/sleep-stager.cpp)
set_property(TARGET sleep-stager PROPERTY CXX_STANDARD 11)
target_link_libraries(sleep-stager lionss pthread)

add_executable(isochrone_15 src/isochrone_15.cpp)
set_property(TARGET isochrone_15 PROPERTY CXX_STANDARD 11)
target_link_libraries(isochrone_15 lionss pthread)

add_executable(shippingrates src/shippingrates.cpp)
set_property(TARGET shippingrates PROPERTY CXX_STANDARD 11)
target_link_libraries(shippingrates lionss pthread)

add_executable(wtpDosing src/wtpDosing.cpp)
set_property(TARGET wtpDosing PROPERTY CXX_STANDARD 11)
target_link_libraries(wtpDosing lionss pthread)

add_executable(hollowtree src/hollowtree.cpp)
set_property(TARGET hollowtree PROPERTY CXX_STANDARD 11)
target_link_libraries(hollowtree lionss pthread)

add_executable(quartz src/quartz.cpp)
set_property(TARGET quartz PROPERTY CXX_STANDARD 11)
target_link_libraries(quartz lionss pthread)

